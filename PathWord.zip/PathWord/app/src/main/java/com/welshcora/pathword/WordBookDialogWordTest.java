package com.welshcora.pathword;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;


public class WordBookDialogWordTest extends BaseDialog {

    DbAdapter mDbAdapter;
    int count = 1;
    RadioButton example1;
    RadioButton example2;
    RadioButton example3;
    RadioButton example4;
    TextView totalCount;
    TextView currentCount;
    int answerCount;
    public Dialog onCreateDialog(Bundle savedInstanceState){
        mBuilder = new AlertDialog.Builder(getActivity());
        LayoutInflater mLaytoutInflater = getActivity().getLayoutInflater();
        view = mLaytoutInflater.inflate(R.layout.activity_test_word, null);


        mBuilder.setView(view);

        return mBuilder.create();
    }
    public void onStart() {
        super.onStart();




        example1 = (RadioButton) view.findViewById(R.id.example1);
        example2 = (RadioButton) view.findViewById(R.id.example2);
        example3 = (RadioButton) view.findViewById(R.id.example3);
        example4 = (RadioButton) view.findViewById(R.id.example4);

        createQuestion();

        example1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (answerCount == 0) {
                    Toast.makeText(getActivity(), "정답입니다", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getActivity(), "오답입니다", Toast.LENGTH_LONG).show();
                }
                example1.setChecked(false);
            }
        });
        example2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (answerCount == 1) {
                    Toast.makeText(getActivity(), "정답입니다", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getActivity(), "오답입니다", Toast.LENGTH_LONG).show();
                }
                example2.setChecked(false);
            }
        });
        example3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (answerCount == 2) {
                    Toast.makeText(getActivity(), "정답입니다", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getActivity(), "오답입니다", Toast.LENGTH_LONG).show();
                }
                example3.setChecked(false);
            }
        });
        example4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (answerCount == 3) {
                    Toast.makeText(getActivity(), "정답입니다", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getActivity(), "오답입니다", Toast.LENGTH_LONG).show();
                }
                createQuestion();
            }
        });


    }
    public void createQuestion(){
        mDbAdapter = new DbAdapter(getActivity()); //디비를 사용할것이다!
        mDbAdapter.open();//디비는 쓸대만 열어두고 아닐땐 닫아야 함. 커서의 버퍼가 차기 때문
        ArrayList<String> wordBookData = mDbAdapter.SelectWordBook("alphabet"); //시간, 단어, 설명
        totalCount = (TextView)view.findViewById(R.id.totalcount);
        totalCount.setText(String.valueOf(wordBookData.size()/3));
        currentCount = (TextView)view.findViewById(R.id.currentcount);
        currentCount.setText(String.valueOf(count));

        TextView sampleWord = (TextView) view.findViewById(R.id.sampleword);
        Random rand = new Random();
        int num = rand.nextInt(wordBookData.size() / 3 - 1);
        sampleWord.setText(wordBookData.get(3 * num + 1));

        ArrayList<RadioButton> examples = new ArrayList<RadioButton>();
        examples.add(example1);
        examples.add(example2);
        examples.add(example3);
        examples.add(example4);

        answerCount = rand.nextInt(3);
        String resultDescription = "";
        Log.v("정답항", String.valueOf(answerCount));
        String description[] = wordBookData.get(3 * num + 2).split(", "); //설명 부분을 토큰으로 나눈다.
        for (int j = 0; j < description.length; j++) { // 몇번째까지가 단어 부호냐?
            if (0 <= j && j < 4) {//4번까지만 form 검사
                char first = description[j].charAt(0);
                char last = description[j].charAt(description[j].length() - 1);
                if ((('A' <= first && first <= 'Z' || 'a' <= first && first <= 'z') ||
                        ('A' <= last && last <= 'Z' || 'a' <= last && last <= 'z') && description[j].length() <= 2) || first == '[') {//토큰의 첫번째 글자와 마지막 글자가 영어거나 글자수가 4이하라면
                } else {
                    resultDescription += description[j] + ", ";
                }
            } else {
                resultDescription += description[j] + ", ";
            }
        }
        examples.get(answerCount).setText(resultDescription.substring(0, resultDescription.length()-2));

        int randomCountList[] = new int[4];
        int answerid = mDbAdapter.SerchId(wordBookData.get(3 * num + 1));
        for(int i = 0; i<4;i++){
            randomCountList[i] = rand.nextInt(mDbAdapter.totalCount()) + 1;//1부터 디비전체 영어단어 갯수 까지
            for(int j = 0; j<i; j++){
                while(randomCountList[i] == randomCountList[j] || randomCountList[i] == answerid) randomCountList[i] = rand.nextInt(mDbAdapter.totalCount()) + 1;
            }
            Log.v("랜덤숫자", String.valueOf(randomCountList[i]));
        }

        for(int i = 0; i < 4; i++){
            if(i == answerCount) continue;//정답 보기는 냅둠.
            resultDescription = "";
            ArrayList<String> randomList = mDbAdapter.SearchWord3(randomCountList);
            String temp[] = randomList.get(i).split(", "); //랜덤으로 선택된 5개의 설명 부분을 토큰으로 나눈다.
            for (int j = 0; j < temp.length; j++) { // 몇번째까지가 단어 부호냐?
                if (0 <= j && j < 4) {//4번까지만 form 검사
                    char first = temp[j].charAt(0);
                    char last = temp[j].charAt(temp[j].length() - 1);
                    if ((('A' <= first && first <= 'Z' || 'a' <= first && first <= 'z') ||
                            ('A' <= last && last <= 'Z' || 'a' <= last && last <= 'z') && temp[j].length() <= 2) || first == '[') {//토큰의 첫번째 글자와 마지막 글자가 영어거나 글자수가 4이하라면
                    } else {
                        resultDescription += temp[j] + ", ";
                    }
                } else {
                    resultDescription += temp[j] + ", ";
                }
            }
            examples.get(i).setText(resultDescription.substring(0, resultDescription.length()-2));
        }
    }
}