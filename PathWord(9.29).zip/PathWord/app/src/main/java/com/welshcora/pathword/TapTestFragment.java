package com.welshcora.pathword;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by DuckG on 2015-09-02.
 */
public class TapTestFragment extends BaseFragment {
    DbAdapter mDbAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v =inflater.inflate(R.layout.tap_test,container,false);
        return v;
    }
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //툴바 설정
        //setToolbar("메인화면");
        //toolbar.setVisibility(View.GONE);
        //폰트 설정
        setFont();
        //커스텀 속성

        mDbAdapter = new DbAdapter(getActivity()); //디비를 사용할것이다!
        mDbAdapter.open();//디비는 쓸대만 열어두고 아닐땐 닫아야 함. 커서의 버퍼가 차기 때문

        mListView = (ListView) getActivity().findViewById(R.id.listView_tap_test);

        mAdapter1 = new ListViewAdapter(getActivity());

        mAdapter1.addItem("날짜워드타입",1, "2", "3", "4", "5", WORDBOOK_TEST_TYPE_WORD);
        mAdapter1.addItem("날짜루트타입",2, "6", "7", "8", "9", WORDBOOK_TEST_TYPE_ROOT);
        mListView.setAdapter(mAdapter1);


        TextView wordtest = (TextView) getActivity().findViewById(R.id.WordTest);
        wordtest.setText(String.valueOf(mDbAdapter.SelectWordBook("recent").size() / 3));

    }
}